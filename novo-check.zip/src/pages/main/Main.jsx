"use client";
import Accordions from "@/components/accordion/Accordions";
import Hero from "@/components/hero/Hero";
import Tabs from "@/components/tabs/Tabs";

import React from "react";

const Main = () => {
  return (
    <>
      <main className="flex min-h-screen flex-col ">
        <Hero />
        <Tabs />
        <Accordions />
      </main>
    </>
  );
};

export default Main;
